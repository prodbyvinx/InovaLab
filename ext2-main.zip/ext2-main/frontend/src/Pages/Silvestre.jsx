import Header from "../components/Header";
import Footer from "../components/Footer";
import TimeLine from "../components/TImeLine";


function Silvestre() {
    return (
        <>
            <Header />
            <TimeLine />
            <Footer />
            
        </>
    );
}

export default Silvestre;
